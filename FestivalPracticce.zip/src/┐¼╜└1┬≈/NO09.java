package 연습1차;

public class NO09 {

	public static void main(String[] args) { // 1분 32초
		
		
		
		for(int i =  65 ; i <= 90 ; i++) {
			
			char alphabet = (char)i;
			
			System.out.println(alphabet);
		}

	}

}
