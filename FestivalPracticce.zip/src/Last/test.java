package Last;

import java.util.Random;
import java.util.Scanner;

public class test {

	public static void main(String[] args) {
		
		
		
	}

}
