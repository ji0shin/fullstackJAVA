package Last;

public class No09 {

	public static void main(String[] args) {
		
		for(int i = 65 ; i <= 90 ; i++) {
			System.out.println((char)i);
		}

	}

}
